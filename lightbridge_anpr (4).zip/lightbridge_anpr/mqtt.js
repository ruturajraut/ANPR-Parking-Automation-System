const mqtt=require('async-mqtt');
const gvl = require('./gvl');

let client = null;
const options = {
    clientId:"bellona-anpr-server-mqtt-client",
    // host : gvl.mqtt_broker_details.server_url,
    port : gvl.mqtt_broker_details.port,
    username:gvl.mqtt_broker_details.user,
    password:gvl.mqtt_broker_details.pass,
    clean:true
};

async function connectClient(){
    // console.log(options);
    try{
        client  = await mqtt.connectAsync(gvl.mqtt_broker_details.server_url,options);
    // console.log("connected flag  "+client.connected);
    }catch (error) {
        console.error("Error during connect to mqtt --:", error);
    }
}


function sendMsgForDisplay(displayId,vehicleNumber,whitelistApproved,ownerName,ownerUnit){
// function sendMsgForDisplay(displayId,vehicleNumber,whitelistApproved){
    sendData = {}
    sendData.vehicleNumber = vehicleNumber;
    sendData.whitelistApproved = whitelistApproved;

    if(whitelistApproved){
        sendData.ownerName = ownerName;
        sendData.ownerUnit = ownerUnit;
    }

    sendData = JSON.stringify(sendData);
    console.log("&&&&&&&&&",sendData)
    publishMessage("anpr-"+displayId,sendData);
}


async function publishMessage(topic,message){
    
    try{
        if(!client || !client.connected) await connectClient();
        
            console.log("is client connected=" + client.connected);
            
            await client.publish(topic, message);
            // console.log("Hello")
            // This line doesn't run until the server responds to the publish
            // await client.end();
            // This line doesn't run until the client has disconnected without error
            // console.log("Done");
    }catch(error){
        console.log("Error !!! at publish msg")
        // Do something about it!
		// console.log(e.stack);
		// process.exit();
    }
	
	
}

module.exports = {
    sendMsgForDisplay
}