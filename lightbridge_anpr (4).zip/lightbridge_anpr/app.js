var express = require('express');
var db = require("./database");
const bodyParser = require("body-parser");
const plc = require('./plc');
// const mqtt = require('./mqtt');
const synchronizeEntryLogs = require('./database').synchronizeEntryLogs;
const synchronizeLocalDataOnline = require('./database').synchronizeLocalDataOnline;
const checkCameraIdForFourWheeler = require('./database').checkCameraIdForFourWheeler;
const vehicleCount = require('./vehicleCount');
const createVehicleCountEntryLog = require('./database').createVehicleCountEntryLog;
const axios = require('axios');
const https = require('https'); // Only import https if your link uses https
const FormData = require('form-data');
const fs = require('fs');


// Initialize totals
let totals = {
    company_counts: {},
    overall_totals: { in_count: 0, out_count: 0 }
};

// Initialize the totals asynchronously
async function initializeTotals() {
    try {
        totals = await db.getAllInitialCounts();
        console.log("totals in ==", totals);
    } catch (error) {
        console.error('Error initializing totals:', error);
    }
}

// Call the initialization
initializeTotals();


var app = express();
const port = 2202;

// serve your css as static
app.use(express.static(__dirname));

// get our app to use body parser 
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json());



setInterval(async function () {
  try {

    await db.syncData();
  } catch (error) {
    console.error('Error synchronizing entry logs:', error);
  }
}, 5000)

async function sendImageToANPRAPI(imageData, plateNumber) {
  try {
      const form = new FormData();

      // console.log("imageData==",imageData)
      // console.log("plateNumber==",plateNumber)

      // Check if the image data is valid and append it properly
      if (!imageData || imageData === 0) {
          console.error("No image data provided");
          return { success: false, reason: "No Image data provided" };
      }

      // If image data is a URL or base64, ensure it's appended correctly
      form.append('image_data', imageData); // This should be base64 string or image URL
      form.append('image_name', plateNumber); // Plate number as the image name

      // Send the image to the API
      const response = await axios.post('https://www.octopus-automation.com/apps/lightbridge/anpr_image_saver.php', form, {
          headers: {
              ...form.getHeaders() // Make sure to add form headers
          }
      });
      // Return the response from ANPR API
      return response.data;
  } catch (error) {
      console.error("Error uploading image to ANPR API:", error);
      return null; // Return null in case of an error
  }
}


const lastVehicleEntryTimestamps = {
  'new-plate-parking-entry-1': new Date(),
  
  'new-plate-main-entry': new Date(),
  'new-plate-parking-exit-1': new Date(),
  
  'new-plate-main-exit': new Date()
};

// 2. Dummy data insertion logic
const DUMMY_INTERVAL = (60 * 60 * 1000) - (5 * 1000); // 59m 55s
// const DUMMY_INTERVAL = 2 * 60 * 1000; // 2 minutes testing 
const CHECK_INTERVAL = 5 * 1000;    // check every 5 seconds

setInterval(async () => {
  const now = new Date();

  for (const cameraId of Object.keys(lastVehicleEntryTimestamps)) {
    const timeSinceLastEntry = now - lastVehicleEntryTimestamps[cameraId];

    if (timeSinceLastEntry > DUMMY_INTERVAL) {
      console.log(`${cameraId}: No entry in the past hour, inserting dummy data...`);

      const dummyPlate = '0';
      const dummyImage = '0';
      const badNo = 0;
      const dummyData = { id: 0, vehicle_number: dummyPlate };

      try {
        if (cameraId === 'new-plate-parking-entry-1') {
          await db.createFourWheelerEntryLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for parking entry 1.`);
        } else if (cameraId === 'new-plate-main-entry') {
          await db.createFourWheelerMainEntryLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for main entry.`);
        }else if (cameraId === 'new-plate-parking-exit-1') {
          await db.createFourWheelerExitLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for parking exit 1.`);
        }else if (cameraId === 'new-plate-main-exit') {
          await db.createFourWheelerMainExitLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for main exit.`);
        }

        // Reset timestamp after dummy data insertion
        lastVehicleEntryTimestamps[cameraId] = new Date();

      } catch (error) {
        console.error(`${cameraId}: Failed to insert dummy data:`, error);
      }
    } else {
      const totalSeconds = Math.floor(timeSinceLastEntry / 1000);
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
      console.log(`${cameraId}: Last real entry was ${formattedTime} (mm:ss) ago, waiting...`);
          }
  }
}, CHECK_INTERVAL);

app.post("/new-plate-parking-entry-1", async (req, res) => {
  // console.log('\n\n----------------');
  // console.log(req.body);
  console.log(`@ ${new Date()}`);

  lastVehicleEntryTimestamps['new-plate-parking-entry-1'] = new Date(); // Update timestamp
  if (!req.body.plate) {
    // console.log("Invalid request: plate number is missing");
    return res.status(400).send({ error: "Plate number is missing" });
  }

  if (req.body.hasOwnProperty("plate") && req.body.plate) {
    var vehicleImage = 0;
    var vehiclePlateNumber = 0;
    if (req.body.hasOwnProperty("plateimage")) {
      vehicleImage = req.body.plateimage;
    }
    if (req.body.hasOwnProperty("plate")) {
      vehiclePlateNumber = req.body.plate;
    }

    try {
      
      // Check if the vehicle is in the whitelist
      const vehicleDetails = await db.checkWhiteList(req.body.plate,"IN");
      // Check if the vehicle is in the bad number list
      const isBadNumber = await db.checkBadNumber(req.body.plate);

      // Default badNo to 0 (non-bad number vehicle)
      let badNo = 0;

      // If vehicle is in the bad number list, set badNo to 1
      if (isBadNumber) {
        badNo = 1;
      }

      if (vehicleDetails) { // if vehicle number was found in the whitelist
        console.log("Open Four Wheeler Parking entry 1st boom for whitelisted vehicle!");
        // open boooooooom 
        await plc.openFourWheelerEntryBoom1();  
       totals.overall_totals.in_count++;

        console.log("totals.overall_totals.in_count ===>",totals.overall_totals.in_count)
        
      //   await db.createFourWheelerEntryLog(
      //     { id: 0, vehicle_number: vehiclePlateNumber },
      //     'file', // Indicates the image is saved on ANPR API
      //     true,
      //     badNo
      // );

        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
            // console.log("imageUploadResponse===",imageUploadResponse)
            
            // Handle the response from the ANPR API
            if (imageUploadResponse && imageUploadResponse.success === true) {
                // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
                // Update the database with "file" if the image is successfully saved
                await db.createFourWheelerEntryLog(
                  { id: 0, vehicle_number: vehiclePlateNumber },
                    'file', // Indicates the image is saved on ANPR API
                    true,
                    badNo
                );
            } else {
                // console.log("storing image URL......");
                // If failed, store the image URL in the database
                await db.createFourWheelerEntryLog(
                    { id: 0, vehicle_number: vehiclePlateNumber },
                    req.body.plateimage, // Storing the image URL in the database
                    true,
                    badNo
                );
            }

        // try {
        //   mqtt.sendMsgForDisplay(
        //     "bellona-parking-entry-1",
        //     vehicleDetails.vehicle_number,
        //     true,
        //     vehicleDetails.owner_name,
        //     vehicleDetails.owner_unit
        //   );
        // } catch (error) {
        //   console.log("Inside 1 entry ")
        //   console.error("Error during MQTT message sending for whitelisted vehicle at entry 1:", error);
        //   // return;
        // }
      } else {
        // console.log("Open Four Wheeler Parking entry 1st boom for non-whitelisted vehicle!");
        // open booooooooooooooooooooom
         await plc.openFourWheelerEntryBoom1();  
       totals.overall_totals.in_count++;

        console.log("totals.overall_totals.in_count non-whitelisted===>",totals.overall_totals.in_count)
        
        // await db.createFourWheelerEntryLog(
        //   { id: 0, vehicle_number: vehiclePlateNumber },
        //     'file', // Indicates the image is saved on ANPR API
        //     false,
        //     badNo
        // );

        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
            // console.log("imageUploadResponse===",imageUploadResponse)
            
            // Handle the response from the ANPR API
            if (imageUploadResponse && imageUploadResponse.success === true) {
                // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
                // Update the database with "file" if the image is successfully saved

                // console.log("vehiclePlateNumber=======",vehiclePlateNumber)
                // console.log("VehicleImg===++",req.body.plateimage)
                await db.createFourWheelerEntryLog(
                  { id: 0, vehicle_number: vehiclePlateNumber },
                    'file', // Indicates the image is saved on ANPR API
                    false,
                    badNo
                );
            } else {
                // console.log("storing img URL...");

                // console.log("vehiclePlateNumber=======",vehiclePlateNumber)
                // console.log("VehicleImg===++",req.body.plateimage)
                
                // If failed, store the image URL in the database
                await db.createFourWheelerEntryLog(
                    { id: 0, vehicle_number: vehiclePlateNumber },
                    req.body.plateimage, // Storing the image URL in the database
                    false,
                    badNo
                );
            }

        // try {
        //   mqtt.sendMsgForDisplay(
        //     "bellona-parking-entry-1",
        //     req.body.plate,
        //     false
        //   );
        // } catch (error) {
        //   console.error("Error during MQTT message sending for non-whitelisted vehicle at entry 1:", error);
        //   // return;
        // }
      }

      res.send(true);
    } catch (error) {
      console.error("Error during processing the entry:", error);
      // res.status(500).send({ error: "Internal server error during processing the entry" });
    }
  } else {
    // res.status(400).send({ error: "Invalid request: plate number is missing" });
    // console.log("Invalid request: plate number is missing")
  }
});



app.post("/new-plate-main-entry", async (req, res) => {
  // console.log('\n\n----------------');
  // console.log(req.body);
  // console.log(`@ ${new Date()}`);

  lastVehicleEntryTimestamps['new-plate-main-entry'] = new Date(); // Update timestamp

  if (!req.body.plate) {
    // console.log("Invalid request: plate number is missing");
    return res.status(400).send({ error: "Plate number is missing" });
  }

  if (req.body.hasOwnProperty("plate") && req.body.plate) {
    var vehicleImage = 0;
    var vehiclePlateNumber = 0;
    if (req.body.hasOwnProperty("plateimage")) {
      vehicleImage = req.body.plateimage;
    }
    if (req.body.hasOwnProperty("plate")) {
      vehiclePlateNumber = req.body.plate;
    }

    try {
      // const vehicleDetails = await db.checkWhiteList(req.body.plate);
      // Check if the vehicle is in the bad number list
      const isBadNumber = await db.checkBadNumber(req.body.plate);

      // Default badNo to 0 (non-bad number vehicle)
      let badNo = 0;

      // If vehicle is in the bad number list, set badNo to 1
      if (isBadNumber) {
        badNo = 1;
      }

      // if (vehicleDetails) { // if vehicle number was found in the whitelist
        // console.log("Open Four Wheeler main entry boom for whitelisted vehicle!");
        // open booooooooooooooooooooom
        await plc.openFourWheelerMainEntryBoom();  
        
        // await db.createFourWheelerMainEntryLog(
        //   { id: 0, vehicle_number: vehiclePlateNumber },
        //     'file', // Indicates the image is saved on ANPR API
        //     true,
        //     badNo
        // );

        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
        // console.log("imageUploadResponse===",imageUploadResponse)
        
        // Handle the response from the ANPR API
        if (imageUploadResponse && imageUploadResponse.success === true) {
            // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
            // console.log("vehicleImg----",req.body.plateimage)
            // Update the database with "file" if the image is successfully saved
            await db.createFourWheelerMainEntryLog(
              { id: 0, vehicle_number: vehiclePlateNumber },
                'file', // Indicates the image is saved on ANPR API
                true,
                badNo
            );
        } else {
            // console.log("storing image URL......");
            // console.log("vehicleImg----",req.body.plateimage)
            // If failed, store the image URL in the database
            await db.createFourWheelerMainEntryLog(
                { id: 0, vehicle_number: vehiclePlateNumber },
                req.body.plateimage, // Storing the image URL in the database
                true,
                badNo
            );
        }
        // try {
        //   mqtt.sendMsgForDisplay(
        //     "bellona-main-entry",
        //     vehicleDetails.vehicle_number,
        //     true,
        //     vehicleDetails.owner_name,
        //     vehicleDetails.owner_unit
        //   );
        // } catch (error) {
        //   console.error("Error during MQTT message sending for whitelisted vehicle at Main entry:", error);
        // }
      // } else {
      //   // console.log("Open Four Wheeler main entry boom for non-whitelisted vehicle!");
      //   // open boooooooooooom
      //   await plc.openFourWheelerMainEntryBoom();
      //   // await db.createFourWheelerMainEntryLog(
      //   //   { id: 0, vehicle_number: vehiclePlateNumber },
      //   //     'file', // Indicates the image is saved on ANPR API
      //   //     false,
      //   //     badNo
      //   // );

      //   const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
      //   // console.log("imageUploadResponse===",imageUploadResponse)
        
      //   // Handle the response from the ANPR API
      //   if (imageUploadResponse && imageUploadResponse.success === true) {
      //       // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
      //       // Update the database with "file" if the image is successfully saved

      //       // console.log("vehiclePlateNumber=======",vehiclePlateNumber)
      //       // console.log("vehicleImg----",req.body.plateimage)
      //       await db.createFourWheelerMainEntryLog(
      //         { id: 0, vehicle_number: vehiclePlateNumber },
      //           'file', // Indicates the image is saved on ANPR API
      //           false,
      //           badNo
      //       );
      //   } else {
      //       // console.log("storing img URL...");

      //       // console.log("vehiclePlateNumber=======",vehiclePlateNumber)
      //       // console.log("vehicleImg----",req.body.plateimage)
            
      //       // If failed, store the image URL in the database
      //       await db.createFourWheelerMainEntryLog(
      //           { id: 0, vehicle_number: vehiclePlateNumber },
      //           req.body.plateimage, // Storing the image URL in the database
      //           false,
      //           badNo
      //       );
      //   }
      // //   // try {
      // //   //   mqtt.sendMsgForDisplay(
      // //   //     "bellona-main-entry",
      // //   //     req.body.plate,
      // //   //     false
      // //   //   );
      // //   // } catch (error) {
      // //   //   console.error("Error during MQTT message sending for non-whitelisted vehicle at main entry:", error);
      // //   // }
      // }

      res.send(true);
    } catch (error) {
      console.error("Error during processing the entry:", error);
      // res.status(500).send({ error: "Internal server error during processing the entry" });
    }
  } else {
    // res.status(400).send({ error: "Invalid request: plate number is missing" });
    // console.log("Invalid request: plate number is missing")
  }
});


app.post("/new-plate-parking-exit-1", async (req, res) => {
  // console.log('\n\n----------------');
  // console.log(req.body);
  // console.log(`@ ${new Date()}`);
  lastVehicleEntryTimestamps['new-plate-parking-exit-1'] = new Date(); // Update timestamp

  if (!req.body.plate) {
    // console.log("Invalid request: plate number is missing");
    return res.status(400).send({ error: "Plate number is missing" });
  }

  if(req.body.hasOwnProperty("plate") && req.body.plate){
    var vehicleImage = 0;
    var vehiclePlateNumber = 0;
  
    // const vehicleDetails = await db.checkWhiteList(req.body.plate);
    if(req.body.hasOwnProperty("plateimage")){vehicleImage = req.body.plateimage};
    if (req.body.hasOwnProperty("plate")) {
      vehiclePlateNumber = req.body.plate;
    }
    try {
      // Check if the vehicle is in the whitelist
      const vehicleDetails = await db.checkWhiteList(vehiclePlateNumber,"OUT");
      // Check if the vehicle is in the bad number list
      const isBadNumber = await db.checkBadNumber(req.body.plate);

      // Default badNo to 0 (non-bad number vehicle)
      let badNo = 0;

      // If vehicle is in the bad number list, set badNo to 1
      if (isBadNumber) {
        badNo = 1;
      }

      // If vehicle is found in the whitelist
      if (vehicleDetails) {
        // console.log("Open Four Wheeler Parking exit 1st boom for whitelisted vehicle!");
        // open boooooooooom
        await plc.openFourWheelerExitBoom1();  
        totals.overall_totals.out_count++;

        console.log("totals.overall_totals.out_count++;====>",totals.overall_totals.out_count)
        // Pass success = true, and bad_no (0 or 1)
        // await db.createFourWheelerExitLog(
        //   { id: 0, vehicle_number: vehiclePlateNumber },
        //     'file', // Indicates the image is saved on ANPR API
        //     true,
        //     badNo
        // );
        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
            // console.log("imageUploadResponse===",imageUploadResponse)
            
            // Handle the response from the ANPR API
            if (imageUploadResponse && imageUploadResponse.success === true) {
                // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
                // console.log("vehicleImg----",req.body.plateimage)
                // Update the database with "file" if the image is successfully saved
                await db.createFourWheelerExitLog(
                  { id: 0, vehicle_number: vehiclePlateNumber },
                    'file', // Indicates the image is saved on ANPR API
                    true,
                    badNo
                );
            } else {
                // console.log("storing image URL......");
                // console.log("vehicleImg----",req.body.plateimage)
                // If failed, store the image URL in the database
                await db.createFourWheelerExitLog(
                    { id: 0, vehicle_number: vehiclePlateNumber },
                    req.body.plateimage, // Storing the image URL in the database
                    true,
                    badNo
                );
            }

      } else {
        // console.log("Open Four Wheeler Parking exit 1st boom for non-whitelisted vehicle!");
        // open boooooooooooooom
        
        await plc.openFourWheelerExitBoom1();  
        totals.overall_totals.out_count++;

        console.log("totals.overall_totals.out_count++;====>",totals.overall_totals.out_count)
   
        // await db.createFourWheelerExitLog(
        //       { id: 0, vehicle_number: vehiclePlateNumber },
        //         'file', // Indicates the image is saved on ANPR API
        //         false,
        //         badNo
        //     );

        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
        // console.log("imageUploadResponse===",imageUploadResponse)
        
        // Handle the response from the ANPR API
        if (imageUploadResponse && imageUploadResponse.success === true) {
            // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
            // Update the database with "file" if the image is successfully saved

            // console.log("vehiclePlateNumber=======",vehiclePlateNumber)
            // console.log("vehicleImg----",req.body.plateimage)
            await db.createFourWheelerExitLog(
              { id: 0, vehicle_number: vehiclePlateNumber },
                'file', // Indicates the image is saved on ANPR API
                false,
                badNo
            );
        } else {
            // console.log("storing img URL...");

            // console.log("vehiclePlateNumber=======",vehiclePlateNumber)
            // console.log("vehicleImg----",req.body.plateimage)
            
            // If failed, store the image URL in the database
            await db.createFourWheelerExitLog(
                { id: 0, vehicle_number: vehiclePlateNumber },
                req.body.plateimage, // Storing the image URL in the database
                false,
                badNo
            );
        }

      }

      

      res.send(true);
    } catch (error) {
      console.error("Error during processing the exit:", error);
      res.status(500).send({ error: "Internal server error" });
    }
  } else {
    // console.log("Invalid request: plate number is missing");
    res.status(400).send({ error: "Plate number is missing" });
  }
});



app.post("/new-plate-main-exit", async (req, res) => {
  // console.log('\n\n----------------');
  // console.log(req.body);
  // console.log(`@ ${new Date()}`);

  lastVehicleEntryTimestamps['new-plate-main-exit'] = new Date(); // Update timestamp

  if (!req.body.plate) {
    // console.log("Invalid request: plate number is missing");
    return res.status(400).send({ error: "Plate number is missing" });
  }

  if(req.body.hasOwnProperty("plate") && req.body.plate){
  
    
    if(req.body.hasOwnProperty("plateimage")){vehicleImage = req.body.plateimage};
    if (req.body.hasOwnProperty("plate")) {
      vehiclePlateNumber = req.body.plate;
    }
    try {
      // Check if the vehicle is in the whitelist
      // const vehicleDetails = await db.checkWhiteList(req.body.plate);
      // Check if the vehicle is in the bad number list
      const isBadNumber = await db.checkBadNumber(req.body.plate);

      // Default badNo to 0 (non-bad number vehicle)
      let badNo = 0;

      // If vehicle is in the bad number list, set badNo to 1
      if (isBadNumber) {
        badNo = 1;
      }

      // If vehicle is found in the whitelist
      // if (vehicleDetails) {
        // console.log("Open Four Wheeler Main exit boom for whitelisted vehicle!")
        // open boooooooooooooooooooom;
        await plc.openFourWheelerMainExitBoom();
        // await db.createFourWheelerMainExitLog(
              //   { id: 0, vehicle_number: vehiclePlateNumber },
              //     'file', // Indicates the image is saved on ANPR API
              //     true,
              //     badNo
              // );
        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
            // console.log("imageUploadResponse===",imageUploadResponse)
            
            // Handle the response from the ANPR API
            if (imageUploadResponse && imageUploadResponse.success === true) {
                // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
                // console.log("vehicleImg----",req.body.plateimage)
                // Update the database with "file" if the image is successfully saved
                await db.createFourWheelerMainExitLog(
                  { id: 0, vehicle_number: vehiclePlateNumber },
                    'file', // Indicates the image is saved on ANPR API
                    true,
                    badNo
                );
            } else {
                // console.log("storing image URL......");
                // console.log("vehicleImg----",req.body.plateimage)
                // If failed, store the image URL in the database
                await db.createFourWheelerMainExitLog(
                    { id: 0, vehicle_number: vehiclePlateNumber },
                    req.body.plateimage, // Storing the image URL in the database
                    true,
                    badNo
                );
            }
      // } else {
      //   // console.log("Open Four Wheeler Main exit boom for non-whitelisted vehicle!");
      //   // open boom
      //   await plc.openFourWheelerMainExitBoom(); 
      //   // Log for non-whitelisted vehicles with bad_no (0)
      //   // db.createFourWheelerMainExitLog({ id: 0, vehicle_number: req.body.plate }, vehicleImage, false, badNo);
      //   // await db.createFourWheelerMainExitLog(
      //   //   { id: 0, vehicle_number: vehiclePlateNumber },
      //   //     'file', // Indicates the image is saved on ANPR API
      //   //     false,
      //   //     badNo
      //   // );
      //   const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
      //       // console.log("imageUploadResponse===",imageUploadResponse)
            
      //       // Handle the response from the ANPR API
      //       if (imageUploadResponse && imageUploadResponse.success === true) {
      //           // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
      //           // console.log("vehicleImg----",req.body.plateimage)
      //           // Update the database with "file" if the image is successfully saved
      //           await db.createFourWheelerMainExitLog(
      //             { id: 0, vehicle_number: vehiclePlateNumber },
      //               'file', // Indicates the image is saved on ANPR API
      //               false,
      //               badNo
      //           );
      //       } else {
      //       //     console.log("storing image URL......");
      //       //     console.log("vehicleImg----",req.body.plateimage)
      //           // If failed, store the image URL in the database
      //           await db.createFourWheelerMainExitLog(
      //               { id: 0, vehicle_number: vehiclePlateNumber },
      //               req.body.plateimage, // Storing the image URL in the database
      //               false,
      //               badNo
      //           );
      //       }
      // }
      res.send(true);
    } catch (error) {
      console.error("Error during processing the main exit:", error);
      res.status(500).send({ error: "Internal server error" });
    }
  } else {
    // console.log("Invalid request: plate number is missing");
    res.status(400).send({ error: "Plate number is missing" });
  }
});


function resetTotals() {
    totals = {
        company_counts: {},
        overall_totals: { in_count: 0, out_count: 0 }
    };
    console.log("Totals reset to 0 at end of day:", new Date().toISOString());
}

// Schedule daily reset at 23:59:59
function scheduleDailyReset() {
    const now = new Date();
    const targetTime = new Date();
    targetTime.setHours(23, 59, 59, 0);
    
    // If it's already past 23:59:59 today, schedule for tomorrow
    if (now > targetTime) {
        targetTime.setDate(targetTime.getDate() + 1);
    }
    
    const timeUntilReset = targetTime.getTime() - now.getTime();
    
    setTimeout(() => {
        resetTotals();
        // Schedule next reset for the following day
        scheduleDailyReset();
    }, timeUntilReset);
    
    console.log(`Daily reset scheduled for: ${targetTime}`);
}

// Start the scheduler
scheduleDailyReset();

// app.post("/vehicleCount", async (req, res) => {
//   console.log("recieving vehicle count data....")
//   console.dir(req.body,{depth:4});
//   console.log(`@ ${new Date()}`);
//   vehicleCount.getVehicleCounts(req.body);
// });
// app.post("/vehicleCount", async (req, res) => {
//   console.log("Receiving vehicle count data....");
//   console.dir(req.body, { depth: 4 });
//   console.log(`@ ${new Date()}`);

//   try {
//     // Assuming `vehicleCount.getVehicleCounts` processes the data and generates the required counts
//     const counts = vehicleCount.getVehicleCounts(req.body);

//     // Call `createVehicleCountEntryLog` with the processed counts
//     await createVehicleCountEntryLog(counts);

//     // res.send({ success: true });
//   } catch (error) {
//     console.error("Error while processing vehicle count data:", error);
//     // res.status(500).send({ error: "Internal server error during vehicle count processing" });
//   }
// });
app.post("/vehicleCount", async (req, res) => {
  // console.log("Receiving vehicle count data....");
  console.dir(req.body, { depth: 4 });
  // console.log(`@ ${new Date()}`);

  try {
      // Assuming `getVehicleCounts` processes the data and generates the required counts
      const counts = vehicleCount.getVehicleCounts(req.body);
      console.log("Processed counts:", counts); // Log the counts here to check

      if (!counts) {
          throw new Error('Counts are undefined or invalid');
      }

      // Call `createVehicleCountEntryLog` with the processed counts
      await createVehicleCountEntryLog(counts);

      res.send({ success: true });
  } catch (error) {
      console.error("Error while processing vehicle count data:", error);
      res.status(500).send({ error: "Internal server error during vehicle count processing" });
  }
});



app.listen(port, () => {
    console.log(`NodeJS Server for listening to Panasonic ANPR Data. Running on port:${port}`);
    console.log(`Developed by : Claypot Technologies`);
    console.log('Author : Gautam Kulkarni')
  })


