controller_net_id="192.168.20.65.1.1"
controller_net_id2 = "192.168.20.58.1.1"
controller_port = 851

camera_ip = "192.168.15.78"

mqtt_broker_details = {
    'server_url' : 'octopus-3w6ea9.a03.euc1.aws.hivemq.cloud',
    'user' : 'hive_octopus',
    'pass' : 'hive_ocTopus_2202',
    'port' :8883,
    'ssl_port' : 8883,
    'websockets_port' : 8884
}

mysql_details = {
    mysqlHostName : "claypot-db-instance.ci3ywfy1btrn.ap-south-1.rds.amazonaws.com",
    mysqlPort : 3306,
    mysqlUser : "claypot_db_user",
    mysqlPassword : "claypot_db_user_password",
    mysqlDatabase : "lightbridge_db",
    whitelistTable : "lightbridge_numberplate_whitelist",
    entryLogTable : "lightbridge_anpr_logs",
    currentVehiclesTable : "lightbridge_current_vehicles",
    countLogTable : "lightbridge_parking_count_panasonic",
    badNumberTable: 'lightbridge_bad_numbers'
}
mysql_details_local = {
    mysqlHostName : "localhost",
    mysqlPort : 3306,
    mysqlUser : "root",
    mysqlPassword : "root",
    mysqlDatabase : "lightbridge_db",
    entryLogTable : "lightbridge_anpr_logs_local",
    currentVehiclesTable : "lightbridge_current_vehicles_local",
    countLogTable : 'lightbridge_parking_count_panasonic_local'
}

module.exports = {
    controller_net_id,
    controller_net_id2,
    controller_port,
    mqtt_broker_details,
    mysql_details,mysql_details_local
}
