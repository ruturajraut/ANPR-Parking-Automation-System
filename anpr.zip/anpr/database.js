
const mysql = require('mysql2');
const gvl = require('./gvl');
const isOnline = import('is-online');

// ────────────────────────────────────────────────
// MySQL Connections
// ────────────────────────────────────────────────
const pool = mysql.createPool({
  host: gvl.mysql_details.mysqlHostName,
  port: gvl.mysql_details.mysqlPort,
  user: gvl.mysql_details.mysqlUser,
  password: gvl.mysql_details.mysqlPassword,
  database: gvl.mysql_details.mysqlDatabase,
  waitForConnections: true,
  connectionLimit: 10,
  multipleStatements: true,
  timezone: '+05:30'
});

const localPool = mysql.createPool({
  host: gvl.mysql_details_local.mysqlHostName,
  port: gvl.mysql_details_local.mysqlPort,
  user: gvl.mysql_details_local.mysqlUser,
  password: gvl.mysql_details_local.mysqlPassword,
  database: gvl.mysql_details_local.mysqlDatabase,
  waitForConnections: true,
  connectionLimit: 10,
  multipleStatements: true,
  dateStrings: true,
  timezone: '+05:30'
});

// ────────────────────────────────────────────────
// Helper: start of current hour (IST)
// ────────────────────────────────────────────────
function getCurrentHourIST() {
  const now = new Date();
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
  const istOffsetMs = 5.5 * 60 * 60 * 1000;
  const istDate = new Date(utcMs + istOffsetMs);
  istDate.setMinutes(0, 0, 0);
  return istDate;
}

// ────────────────────────────────────────────────
// In‑memory caches
// ────────────────────────────────────────────────
let whitelistCache = [];           // all whitelist vehicles
let companyLimitsCache = {};        // company → limit
let companyLiveCounts = {};         // company → current in‑premise count

// ────────────────────────────────────────────────
// Cache loaders
// ────────────────────────────────────────────────
async function loadWhitelistCache() {
  const promisePool = pool.promise();
  const [rows] = await promisePool.query(
    'SELECT vehicle_number, company_name FROM lightbridge_numberplate_whitelist'
  );
  whitelistCache = rows.map(r => ({
    vehicle_number: r.vehicle_number.trim().toUpperCase(),
    company_name: r.company_name ? r.company_name.trim() : 'Not-WhiteListed'
  }));
  console.log(`✅ Loaded ${whitelistCache.length} whitelist records into cache`);
}

async function loadCompanyLimitsCache() {
  const promisePool = pool.promise();
  const [rows] = await promisePool.query(
    'SELECT company_name, parking_slots FROM lightbridge_company_parking_limits'
  );
  companyLimitsCache = {};
  rows.forEach(r => {
    companyLimitsCache[r.company_name.trim()] = parseInt(r.parking_slots, 10) || 0;
  });
//   console.log('✅ Loaded company limits:', companyLimitsCache);
}


async function initializeCaches() {
    await loadWhitelistCache();
    await loadCompanyLimitsCache();
    

    return {
        whitelistCache,
        companyLimitsCache,
        
    };
}


// ────────────────────────────────────────────────
// Core checkWhiteList + hourly update function
// ────────────────────────────────────────────────
async function updateCompanyVehicleCount(companyName, entryType) {
  const promisePool = pool.promise();
  const hourStart = getCurrentHourIST();
  const now = new Date();
  const inCount = entryType === 'IN' ? 1 : 0;
  const outCount = entryType === 'OUT' ? 1 : 0;

  const query = `
    INSERT INTO lightbridge_vehicle_count_hourly
      (company_name, hour_start, in_count, out_count, last_updated)
    VALUES (?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      in_count = in_count + VALUES(in_count),
      out_count = out_count + VALUES(out_count),
      last_updated = VALUES(last_updated)
  `;
  await promisePool.query(query, [companyName, hourStart, inCount, outCount, now]);
}

async function checkWhiteList(plate, entryType) {
  plate = plate.toUpperCase().trim();
  const promisePool = pool.promise();
  const query = `SELECT * FROM ${gvl.mysql_details.whitelistTable} WHERE vehicle_number = ?`;

  try {
    const [rows] = await promisePool.query(query, [plate]);

    if (rows.length > 0) {
      const row = rows[0];
      const companyName = row.company_name ? row.company_name.trim() : 'Not-WhiteListed';

      const cachedVehicle = whitelistCache.find(v => v.vehicle_number === plate);
      if (cachedVehicle) {
        console.log(` ${plate} found in whitelistCache =>`, cachedVehicle);
      } else {
        console.warn(` ${plate} not found in whitelistCache (maybe DB updated recently)`);
      }

      await updateCompanyVehicleCount(companyName, entryType);
      return { ...row, cachedVehicle: cachedVehicle || null };
    } else {
      await updateCompanyVehicleCount('Not-WhiteListed', entryType);
      return false;
    }
  } catch (e) {
    console.error('Error checking whitelist:', e);
    return false;
  }
}

// ────────────────────────────────────────────────
// Initial totals for dashboards
// ────────────────────────────────────────────────
async function getAllInitialCounts() {
  let company_counts = {};
  let overall_in_count = 0;
  let overall_out_count = 0;

  try {
    const promisePool = pool.promise();
    const today_date = new Date().toISOString().split('T')[0];
    const start_time = `${today_date} 00:00:00`;

    const [rows] = await promisePool.execute(
      `
        SELECT company_name,
               SUM(in_count) as total_in_count,
               SUM(out_count) as total_out_count
        FROM lightbridge_vehicle_count_hourly
        WHERE hour_start >= ?
        GROUP BY company_name
      `,
      [start_time]
    );

    rows.forEach(r => {
      const name = r.company_name;
      const inC = r.total_in_count ? parseInt(r.total_in_count) : 0;
      const outC = r.total_out_count ? parseInt(r.total_out_count) : 0;
      company_counts[name] = { in_count: inC, out_count: outC };
      overall_in_count += inC;
      overall_out_count += outC;
    });
  } catch (e) {
    console.error('Error while fetching initial counts:', e);
  }

  return {
    company_counts,
    overall_totals: { in_count: overall_in_count, out_count: overall_out_count }
  };
}

// ────────────────────────────────────────────────
// Safe getters for caches
// ────────────────────────────────────────────────
async function getWhitelistCache() {
  return whitelistCache;
}
async function getCompanyLimitsCache() {
  return companyLimitsCache;
}
async function getCompanyLiveCounts() {
  return companyLiveCounts;
}


function getISTDateTime() {
  const date = new Date();
  // IST is UTC +5:30
  const offset = 5.5 * 60; // minutes
  const utc = date.getTime() + date.getTimezoneOffset() * 60000;
  const istDate = new Date(utc + offset * 60000);
  return istDate.toISOString().slice(0, 19).replace('T', ' '); // MySQL DATETIME format
}






function getISTDateTime() {
    const now = new Date();
    const utcMs = now.getTime() + (now.getTimezoneOffset() * 60000);
    const istOffsetMs = 5.5 * 60 * 60 * 1000;
    return new Date(utcMs + istOffsetMs);
}

async function updateCompanyVehicleCount(companyName, entryType) {
    const promisePool = pool.promise();
    const hourStartIST = getCurrentHourIST();
    const last_update = getISTDateTime(); // ✅ capture current IST time once

    const inCount = entryType.toUpperCase() === 'IN' ? 1 : 0;
    const outCount = entryType.toUpperCase() === 'OUT' ? 1 : 0;

    const query = `
        INSERT INTO lightbridge_vehicle_count_hourly
            (company_name, hour_start, in_count, out_count, last_updated)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            in_count = in_count + VALUES(in_count),
            out_count = out_count + VALUES(out_count),
            last_updated = VALUES(last_updated)
    `;

    try {
        await promisePool.query(query, [companyName, hourStartIST, inCount, outCount, last_update]);
        console.log(`✅ Updated counts for ${companyName} [${entryType}] at ${hourStartIST} (last_updated: ${last_update})`);
    } catch (err) {
        console.error("❌ Error updating vehicle count:", err);
    }
}


async function checkBadNumber(plate){
    
    plate = plate.toUpperCase();
    let query = `SELECT * FROM ${gvl.mysql_details.badNumberTable} where vehicle_number='${plate}'`;
    
    // console.log(query);

    try{
        const promisePool = pool.promise();
        
        // query database using promises
        const [rows,fields] = await promisePool.query(query);
        // console.log(rows);

        if (rows.length > 0) {
           
            // Return the updated row from badNumberTable
            return true;
        } else {
            return false;  // If plate is not found in badNumberTable
        }
    }
    catch(e){
        //console.log(e.stack);
        //me
        return false;

    }
}

async function createFourWheelerEntryLog(vehicleDetails, vehicleImage, success, badNo = 0) {
    let dt = new Date();
    const offset = dt.getTimezoneOffset();  // Get timezone offset
    dt = new Date(dt.getTime() - (offset * 60 * 1000)); // Adjust to local time

    const splitArr = dt.toISOString().split('T');
    const dtString = splitArr[0]; // Date in YYYY-MM-DD
    const tmStringRaw = splitArr[1];
    const tmString = tmStringRaw.split('.')[0]; // Time in HH:MM:SS
    const dttmString = `${dtString} ${tmString}`; // Full datetime

    try {
        const promisePool = pool.promise();

        const query = `INSERT INTO ${gvl.mysql_details.entryLogTable} 
            (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        await promisePool.query(query, [
            0,
            vehicleDetails.vehicle_number,
            "parking-entry-1",
            success,
            dtString,
            tmString,
            vehicleImage,
            badNo
        ]);
    } catch (e) {
        console.log("Error while inserting into entry log table, using local fallback.");
        await createFourWheelerEntryLogLocal(vehicleDetails, vehicleImage, success, badNo);
        return;
    }

    // Skip dummy entries in current vehicle tracking
    if (vehicleDetails.vehicle_number && vehicleDetails.vehicle_number !== '0') {
        try {
            const promisePool = pool.promise();
    
            // Format date and time strings
            const now = new Date();
            const y = now.getFullYear();
            const m = String(now.getMonth() + 1).padStart(2, '0');
            const d = String(now.getDate()).padStart(2, '0');
            const h = String(now.getHours()).padStart(2, '0');
            const min = String(now.getMinutes()).padStart(2, '0');
            const s = String(now.getSeconds()).padStart(2, '0');
    
            const dtString = `${y}-${m}-${d}`;
            const tmString = `${h}:${min}:${s}`;
            const dttmString = `${dtString} ${tmString}`;
    
            // Sanitize and extract vehicle parts
            const plate = vehicleDetails.vehicle_number.toUpperCase().trim();
            const lastFourDigits = plate.slice(-4);
            const middleFourDigits = plate.substring(4, 8);
    
            // Use parameterized query for safety
            const checkQuery = `SELECT vehicle_number FROM ${gvl.mysql_details.currentVehiclesTable} 
                WHERE (vehicle_number LIKE ? OR vehicle_number LIKE ?) 
                AND entry_dt = ?`;
    
            const [rows] = await promisePool.query(checkQuery, [`%${lastFourDigits}%`, `%${middleFourDigits}%`, dtString]);
    
            if (rows.length > 0) {
                console.log(`Vehicle ${plate} already exists in current vehicles table`);
                return;
            }
    
            // Insert new record
            const insertQuery = `INSERT INTO ${gvl.mysql_details.currentVehiclesTable} 
                (vehicle_number, entry_dt, entry_tm, entry_dttm, in_premise) 
                VALUES (?, ?, ?, ?, ?)`;
    
            await promisePool.query(insertQuery, [plate, dtString, tmString, dttmString, true]);
    
            console.log(`Vehicle ${plate} inserted into current vehicles table at ${dttmString}`);
        } catch (e) {
            console.error("Error while inserting into currentVehiclesTable:", e.stack);
        }
    } else {
        console.log("Skipping current vehicle update due to dummy vehicle number.");
    }
    
}


async function createFourWheelerEntryLogLocal(vehicleDetails, vehicleImage, success, badNo = 0) {
    console.log("----&&");

    // Get the current date and time, adjusted for local timezone
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset * 60 * 1000)); // Convert to local time

    const splitArr = dt.toISOString().split('T');
    const dtString = splitArr[0]; // YYYY-MM-DD
    const tmString = splitArr[1].split('.')[0]; // HH:MM:SS (no milliseconds)

    // Skip dummy data
    if (!vehicleDetails.vehicle_number || vehicleDetails.vehicle_number === '0') {
        console.log("Skipping local log insertion for dummy vehicle number.");
        return;
    }

    try {
        const promisePool = localPool.promise();

        const query = `INSERT INTO ${gvl.mysql_details_local.entryLogTable} 
            (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        await promisePool.query(query, [
            vehicleDetails.id || 0,
            vehicleDetails.vehicle_number,
            "parking-entry-1",
            success,
            dtString,
            tmString,
            vehicleImage,
            badNo
        ]);
    } catch (e) {
        console.log("Error while inserting into local entry log table:");
        console.log(e.stack);
    }
}



//--------------------------------------------
async function createFourWheelerMainEntryLog(vehicleDetails, vehicleImage, success, badNo = 0) {
    // Get current local datetime
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset * 60 * 1000)); // Adjust to local time

    const splitArr = dt.toISOString().split('T');
    const dtString = splitArr[0]; // YYYY-MM-DD
    const tmString = splitArr[1].split('.')[0]; // HH:MM:SS without milliseconds

    // Log when dummy data is being processed
    if (!vehicleDetails.vehicle_number || vehicleDetails.vehicle_number === '0') {
        console.log("[DUMMY LOG] Inserting dummy main entry log (no vehicle data detected).");
    }

    try {
        const promisePool = pool.promise();

        const query = `INSERT INTO ${gvl.mysql_details.entryLogTable} 
            (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        const [rows, fields] = await promisePool.query(query, [
            vehicleDetails.id || 0,
            vehicleDetails.vehicle_number || '0',
            "main entry",
            success,
            dtString,
            tmString,
            vehicleImage,
            badNo
        ]);

        console.log("Main entry log inserted successfully.");
    } catch (e) {
        console.log("Error inserting into main entry log. Falling back to local.");
        console.log(e.stack);
        await createFourWheelerMainEntryLogLocal(vehicleDetails, vehicleImage, success, badNo);
        return;
    }

    // No currentVehiclesTable update for dummy entries
    if (vehicleDetails.vehicle_number && vehicleDetails.vehicle_number !== '0') {
        console.log("Skipping current vehicle table update for main entry — handled elsewhere.");
    } else {
        console.log("No update to currentVehiclesTable for dummy main entry.");
    }
}


async function createFourWheelerMainEntryLogLocal(vehicleDetails, vehicleImage, success, badNo = 0) {
    console.log("----&&");

    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset * 60 * 1000)); // Convert to local time

    const splitArr = dt.toISOString().split('T');
    const dtString = splitArr[0]; // YYYY-MM-DD
    const tmString = splitArr[1].split('.')[0]; // HH:MM:SS

    // Skip dummy entries
    if (!vehicleDetails.vehicle_number || vehicleDetails.vehicle_number === '0') {
        console.log("Skipping local main entry log for dummy vehicle.");
        return;
    }

    try {
        const promisePool = localPool.promise();

        const query = `INSERT INTO ${gvl.mysql_details_local.entryLogTable} 
            (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        const [rows, fields] = await promisePool.query(query, [
            vehicleDetails.id || 0,
            vehicleDetails.vehicle_number,
            "main entry",
            success,
            dtString,
            tmString,
            vehicleImage,
            badNo
        ]);

        console.log("Local main entry log inserted:", rows);

    } catch (e) {
        console.log("Error in local main entry log insert:", e.stack);
    }
}

//------------------------------------


async function createFourWheelerExitLog(vehicleDetails, vehicleImage, success, badNo = 0) {
    console.log("Inserting exit log...");

    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset * 60 * 1000));
    const [dtString, tmRaw] = dt.toISOString().split('T');
    const tmString = tmRaw.split('.')[0];
    const dttmString = `${dtString} ${tmString}`;

    try {
        const promisePool = pool.promise();

        const query = `INSERT INTO ${gvl.mysql_details.entryLogTable} 
            (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        await promisePool.query(query, [
            vehicleDetails.id || 0,
            vehicleDetails.vehicle_number || '0',
            "parking-exit-1",
            success,
            dtString,
            tmString,
            vehicleImage,
            badNo
        ]);

        console.log("Exit log inserted successfully.");
    } catch (e) {
        console.log("Error inserting into online exit log, switching to local log.");
        await createFourWheelerExitLogLocal(vehicleDetails, vehicleImage, success, badNo);
        return;
    }

    // Skip updating currentVehiclesTable for dummy vehicle
    if (!vehicleDetails.vehicle_number || vehicleDetails.vehicle_number === '0') {
        console.log("Skipping update of currentVehiclesTable for dummy vehicle.");
        return;
    }

    try {
        const promisePool = pool.promise();
        const lastFour = vehicleDetails.vehicle_number.slice(-4);
        const middleFour = vehicleDetails.vehicle_number.substring(4, 8);

        const updateQuery = `UPDATE ${gvl.mysql_details.currentVehiclesTable} 
            SET in_premise = 0, exit_dt = ?, exit_tm = ?, exit_dttm = ?
            WHERE vehicle_number LIKE ? OR vehicle_number LIKE ?`;

        await promisePool.query(updateQuery, [
            dtString,
            tmString,
            dttmString,
            `%${lastFour}%`,
            `%${middleFour}%`
        ]);

        console.log("Vehicle status updated for exit.");

    } catch (e) {
        console.log("Error updating currentVehiclesTable:", e.stack);
    }
}


// copy fn of exit
async function createFourWheelerExitLogLocal(vehicleDetails, vehicleImage, success, badNo = 0) {
    console.log("Inserting local exit log...");

    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - offset * 60 * 1000); // Adjust for timezone
    const [dtString, tmRaw] = dt.toISOString().split('T');
    const tmString = tmRaw.split('.')[0];
    const dttmString = `${dtString} ${tmString}`;

    try {
        const promisePool = localPool.promise();

        let query = `INSERT INTO ${gvl.mysql_details_local.entryLogTable} 
                     (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        await promisePool.query(query, [
            vehicleDetails.id || 0,
            vehicleDetails.vehicle_number || '0',
            "parking-exit-1",
            success,
            dtString,
            tmString,
            vehicleImage,
            badNo
        ]);

        console.log("Local exit log inserted successfully.");
    } catch (e) {
        console.log("Error inserting exit log into local table:", e.stack);
        return;
    }

    // Skip dummy vehicle update
    if (!vehicleDetails.vehicle_number || vehicleDetails.vehicle_number === '0') {
        console.log("Skipping update of local currentVehiclesTable for dummy vehicle.");
        return;
    }

    try {
        const promisePool = localPool.promise();

        const updateQuery = `UPDATE ${gvl.mysql_details_local.currentVehiclesTable} 
                             SET in_premise = 0, exit_dt = ?, exit_tm = ?, exit_dttm = ? 
                             WHERE vehicle_number = ?`;

        await promisePool.query(updateQuery, [
            dtString,
            tmString,
            dttmString,
            vehicleDetails.vehicle_number
        ]);

        console.log("Local currentVehiclesTable updated successfully for exit.");
    } catch (e) {
        console.log("Error updating local currentVehiclesTable:", e.stack);
    }
}



async function createFourWheelerMainExitLog(vehicleDetails, vehicleImage, success, badNo = 0) {
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset * 60 * 1000)); // Adjust to local time
    const [dtString, tmRaw] = dt.toISOString().split('T');
    const tmString = tmRaw.split('.')[0]; // Remove milliseconds
    const dttmString = `${dtString} ${tmString}`;

    // Log dummy vehicle (no number or '0')
    if (!vehicleDetails.vehicle_number || vehicleDetails.vehicle_number === '0') {
        console.log("[DUMMY LOG] Main exit log attempt for dummy vehicle number.");
    }

    try {
        const promisePool = pool.promise();

        const query = `INSERT INTO ${gvl.mysql_details.entryLogTable} 
                       (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

        await promisePool.query(query, [
            vehicleDetails.id || 0,
            vehicleDetails.vehicle_number || '0',
            "main exit",
            success,
            dtString,
            tmString,
            vehicleImage,
            badNo
        ]);

        console.log("Main exit log inserted successfully.");
    } catch (e) {
        console.error("Error inserting into main exit log. Falling back to local:", e.stack);
        createFourWheelerMainExitLogLocal(vehicleDetails, vehicleImage, success, badNo);
        return;
    }

    // Skip updating currentVehiclesTable for dummy records
    if (!vehicleDetails.vehicle_number || vehicleDetails.vehicle_number === '0') {
        console.log("Skipping current vehicle update for dummy main exit log.");
        return;
    }

    // No update to currentVehiclesTable by design (as per old version)
    console.log("Main exit completed. No current vehicle table update required.");
}



async function createFourWheelerMainExitLogLocal(vehicleDetails, vehicleImage, success, badNo = 0) {
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset * 60 * 1000)); // Adjust to correct timezone
    const [dtString, tmStringRaw] = dt.toISOString().split('T');
    const tmString = tmStringRaw.split('.')[0]; // Trim milliseconds
    const dttmString = dtString + " " + tmString; // Full datetime string

    console.log("Inserting into local main exit log...");

    try {
        const promisePool = localPool.promise();

        // Prepare query to insert the log into the local entry log table
        let query = `
            INSERT INTO ${gvl.mysql_details_local.entryLogTable} 
            (owner_id, vehicle_number, camera_id, success, date, time, img, bad_no) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;

        // Execute the query using parameterized values to avoid SQL injection
        const [rows, fields] = await promisePool.query(query, [
            vehicleDetails.id, // Owner ID
            vehicleDetails.vehicle_number, // Vehicle Number
            "main exit", // Camera ID
            success, // Success flag
            dtString, // Date
            tmString, // Time
            vehicleImage, // Vehicle Image
            badNo // Bad Number
        ]);

        console.log("Local main exit log inserted successfully:", rows);
    } catch (e) {
        console.error("Error inserting into local main exit log:", e.stack);
    }
}




async function createVehicleCountEntryLog({ carEntryCount, carExitCount, bikeEntryCount, bikeExitCount }) {
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset * 60 * 1000)); // Adjust time for the timezone offset
    const [dtString, tmString] = dt.toISOString().split('T'); // Split the date and time

    try {
        const promisePool = pool.promise();
        const query = `INSERT INTO ${gvl.mysql_details.countLogTable} 
                       (date, time, parking_entry_bike, parking_entry_car, parking_exit_bike, parking_exit_car) 
                       VALUES (?,?,?,?,?,?)`;

        // Insert data with defaults to 0 if any count is null or undefined
        const [rows, fields] = await promisePool.query(query, [
            dtString,
            tmString,
            bikeEntryCount || 0,
            carEntryCount || 0,
            bikeExitCount || 0,
            carExitCount || 0
        ]);

        console.log("Query successful:", rows);
    } catch (e) {
        console.error("Error inserting vehicle count:", e.stack);
    }
}




//------------------------------
//sync function
//-----------------------------

async function syncData() {
    try {
        const localLogs = await fetchLocalLogs(); // Assuming this function fetches local log entries

        var vehicle_log = [];
        for (const vehicleLog of localLogs) {
            vehicle_log.push(vehicleLog);
        }

        syncLogsOnline(vehicle_log, function (success) {
            // console.log("Sync func called");
            if (success) {
                console.log("Inside if: Sync successful");
                // Assuming removeRecordFromLocalTable removes all records synced successfully
                syncCurrentTable(vehicle_log);
                removeRecordFromLocalTable(vehicle_log);
            } else {
                // console.log("Inside else: Sync failed");
                // Handle failure scenario
            }
        });
    } catch (error) {
        console.error("Error occurred during data synchronization:", error);
    }
}



// Function to fetch entry logs from the local entry log table
async function fetchLocalLogs() {
    // Implement logic to fetch entry logs from the local entry log table
    try {
        // Create a connection pool for the local database
        const promisePool = localPool.promise();
        // Fetch entry logs from the local entry log table
        const query = "SELECT * FROM lightbridge_anpr_logs_local"; // Modify query according to your table structure
        const [rows, fields] = await promisePool.query(query);
        
        return rows;
        
    } catch (error) {
        console.error("Error occurred while fetching local entry logs:", error);
        return []; // Return an empty array in case of error
    }

}


// Function to synchronize a local entry log with the online entry log table
async function syncLogsOnline(vehicle_log,callback) {
    try {
        // console.log("inside synclogs---");
        // console.log("vehicle_log",vehicle_log);
        var query = '';
        for(const vlog of vehicle_log) {
        
            // Attempt to insert the entry log into the online entry log table
            var promisePool = pool.promise();
            
            query += `INSERT INTO lightbridge_anpr_logs(owner_id, vehicle_number, camera_id, success, date, time,img,bad_no) values(${vlog.owner_id},'${vlog.vehicle_number}','${vlog.camera_id}',${vlog.success},'${vlog.date}','${vlog.time}','${vlog.img}','${vlog.badNo}');`;
            

        }
        // console.log("Querryy---=",query)
        const [rows, fields] = await promisePool.query(query)
        // const [rows, fields] = await promisePool.query(query)

        callback(true);
        // syncCurrentTable(entryLog) 
     
    } catch (error) {

        callback(false);
    }    
}



//this function syncs local log record with online current table
async function syncCurrentTable(x) {
    try {

        // const camera_id = x.camera_id;
        // const dttm = x.date + " " + x.time;
        // console.log("X&&&",x)
        var query='' 
        for(const vlog of x){
            // Create a connection pool for the online database
            const promisePool = pool.promise();
            //console.log("hello ")

            var dttm = vlog.date + " " + vlog.time;

           
            console.log("vloggg",vlog)
            // Check if the record is an entry or an exit
            if (vlog.camera_id === "main entry") {
                console.log("iNSIDE MAIN ENTRY####")
                
                query = `INSERT INTO lightbridge_current_vehicles(vehicle_number,entry_dt,entry_tm,entry_dttm,in_premise) values('${vlog.vehicle_number}','${vlog.date}','${vlog.time}','${dttm}',true)`;
                
                console.log("Entry record synchronized successfully:");
                console.log(query)
                console.log("----------------------")
                
                const [rows,fields]=await promisePool.query(query);

            }
            else if (vlog.camera_id === "main exit") {
                console.log("mAIN EXIT INSIDE******")

                const lastFourDigits = vlog.vehicle_number.substr(vlog.vehicle_number.length - 4);
                const middleFourDigits = vlog.vehicle_number.substring(4, 8);
                    // Prepare the SQL query to update an exit record in the current vehicle table
                    
                query = `UPDATE lightbridge_current_vehicles SET in_premise=0,exit_dt='${vlog.date}',exit_tm='${vlog.time}',exit_dttm='${dttm}' WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;

                console.log(query)
                console.log("----------------------")
                
                const [rows,fields]=await promisePool.query(query);
            }
            

            

        }
         

    } catch (error) {
        // console.error("Error occurred while synchronizing record online:", error);
        // console.log("Not able to sync current table...probably no internet 2");
    }
}


async function removeRecordFromLocalTable(x) {
    try {
        // console.log("x====",x)
        var query=''
        for(const vlog of x){
            var promisePool = localPool.promise();
            query += `DELETE FROM lightbridge_anpr_logs_local WHERE id = ${vlog.id};`;
        }
        // console.log("Queryyyyy-",query)
        await promisePool.query(query);
        // console.log("Record removed from local table:", vlog.id);
    } catch (error) {
        console.error("Error occurred while removing record from local table:", error);
    }
}








// Function to check the camera_id for four-wheeler exits and entries in the local entry log table
async function checkCameraIdForFourWheeler(entryLog) {
    try {
   
        // Create a connection pool for the local database
        const promisePool = localPool.promise();

        // Prepare the SQL query to check the camera_id for the provided vehicle number
        let query = "SELECT * FROM lightbridge_anpr_logs_local WHERE camera_id = ?";

        const [rows, fields] = await promisePool.query(query,[
            entryLog.camera_id
            //camera_id
           
        ]);
        // console.log(promisePool)


        // If count is greater than 0, it means there was an exit for the vehicle
        if (rows.length > 0 ) {
        const promisePool = pool.promise();
        // query = `DELETE FROM ${gvl.mysql_details.currentVehiclesTable} WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        let query = `UPDATE ${gvl.mysql_details.currentVehiclesTable} SET in_premise=0,exit_dt='${dtString}',exit_tm='${tmString}',exit_dttm='${dttmString}'`;
        await promisePool.query(query);

        return 0; // Four-wheeler exit

        } else {
        const promisePool = pool.promise();
        // query = `DELETE FROM ${gvl.mysql_details.currentVehiclesTable} WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        let query = `UPDATE ${gvl.mysql_details.currentVehiclesTable} SET in_premise=1,exit_dt='${dtString}',exit_tm='${tmString}',exit_dttm='${dttmString}'`;
        await promisePool.query(query);
        
        return 1; // Four-wheeler entry

        }
    } catch (error) {
        console.error("Error occurred while checking camera_id for four-wheeler exits and entries:", error);
        return -1; // Return -1 to indicate an error occurred
    }
}



module.exports = {
    pool,
    checkWhiteList,
    checkBadNumber,
    createFourWheelerEntryLog,
    
    createFourWheelerExitLog,
   
    createFourWheelerMainEntryLog,
    createFourWheelerMainExitLog,
    createVehicleCountEntryLog,
    syncData,

    getAllInitialCounts,
    initializeCaches,



  getWhitelistCache,
  getCompanyLimitsCache,
  getCompanyLiveCounts,

  updateCompanyVehicleCount,

  
  
   
}

