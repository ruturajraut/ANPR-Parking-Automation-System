var db = require("./database");

var carEntryCount=0;
var bikeEntryCount = 0;
var carExitCount = 0;
var bikeExitCount = 0;

// function getVehicleCounts(data){
//     carEntryCount = 0;
//     bikeEntryCount = 0;
//     carExitCount = 0;
//     bikeExitCount = 0;

//     if(data.hasOwnProperty("Time")){
//         //convert time to GMT+5:30
//     }

//     //parsing Line 1 - Entry Ramp cars
//     if(data.hasOwnProperty('Line1') && data.Line1.length > 0 && data.Line1[0].hasOwnProperty('list')){
//         // carEntryCount = data.Line1[0].list.reduce((total,arr)=>{
//         //     console.log(arr);
//         //     return total + parseInt(arr[1]);
//         // })

//         //car entry
//         data.Line1[0].list.forEach(function(item){
//             console.log("itemss---",item)
//             carEntryCount += item[1];
//         })

//         // car exit
//         data.Line2[0].list.forEach(function(item){
//             carExitCount += item[2];
//         })

//         //bike entry
//         data.Line3[0].list.forEach(function(item){
//             bikeEntryCount += item[1];
//         })

//         // bike exit
//         data.Line4[0].list.forEach(function(item){
//             bikeExitCount += item[2];
//         })

//     }
//     console.log("cars in=" + carEntryCount);
//     console.log("cars out=" + carExitCount);
//     console.log("bikes in=" + bikeEntryCount);
//     console.log("bikes out=" + bikeExitCount);

//     db.createVehicleCountEntryLog({carEntryCount:carEntryCount,carExitCount:carExitCount,bikeEntryCount:bikeEntryCount,bikeExitCount:bikeExitCount});
// }


function getVehicleCounts(data) {
    let carEntryCount = 0;
    let bikeEntryCount = 0;
    let carExitCount = 0;
    let bikeExitCount = 0;

    if (data.hasOwnProperty("Time")) {
        // convert time to GMT+5:30 (optional step)
    }

    // Parsing Line 1 - Entry Ramp cars
    if (data.hasOwnProperty('Line1') && data.Line1.length > 0 && data.Line1[0].hasOwnProperty('list')) {
        data.Line1[0].list.forEach(function (item) { //Line 1 for car out
            // carEntryCount += item[1];
            carExitCount += item[2];
        });

        // Car exit
        data.Line2[0].list.forEach(function (item) {  // Line 2 for bike out
            // carExitCount += item[2];
            bikeExitCount += item[2];
        });

        // Bike entry
        data.Line3[0].list.forEach(function (item) { //Line 3 for car in
            // bikeEntryCount += item[1];
            carEntryCount += item[1];
        });

        // Bike exit
        data.Line4[0].list.forEach(function (item) { // Line 4 for bike in
            // bikeExitCount += item[2];
            bikeEntryCount += item[1];
        });
    }

    console.log("cars in=" + carEntryCount);
    console.log("cars out=" + carExitCount);
    console.log("bikes in=" + bikeEntryCount);
    console.log("bikes out=" + bikeExitCount);

    const counts = {
        carEntryCount,
        carExitCount,
        bikeEntryCount,
        bikeExitCount
    };

    console.log("Counts to be inserted:", counts);  // Add this log to inspect the returned counts
    return counts;  // Ensure it returns the counts object
}

module.exports = {
    getVehicleCounts
}