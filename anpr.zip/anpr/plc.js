var ads = require('ads-client');
// import ads from 'ads-client';
const gvl = require('./gvl');
// import gvl from './gvl';


// client 1 means Main 
const client = new ads.Client({
    targetAmsNetId: gvl.controller_net_id,
    targetAdsPort: gvl.controller_port,
})

// client 2 means parking

const client2 = new ads.Client({
    targetAmsNetId: gvl.controller_net_id2,
    targetAdsPort: gvl.controller_port,
})

// console.log(client); // Check the client object structure
// console.log("--------------",Object.keys(client)); // Log all method names available on the client


// async function connectClient(){

//     console.log("client.connection.connected)===",client.connection.connected)

//     if(client.connection.connected){
//         return true;
//     }

//     connectionStatus = await client.connect();
//     console.log("connectionStatus+++++++",connectionStatus)
//     console.dir(connectionStatus,{depth:2});
//     return connectionStatus.connected;

// }




// Async function to check the connection and write symbols
async function connectClient() {
    if (client.connection.connected) {
        return true;
    }
    const connectionStatus = await client.connect();
    console.dir(connectionStatus, { depth: 2 });
    return connectionStatus.connected;
}

// Async function to open the main entry boom gate for four-wheelers
// async function openFourWheelerMainEntryBoom() {
//     let connectionStatus = await connectClient();
//     console.log("connectionStatus+++",connectionStatus)
    
//     try {
//         // const res1 = await client.read('GVL.is_vehicle_transaction_on');
//         // console.log("==",res1);
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true);
//         const res = await client.writeSymbol('GVL.mainGateBoomBarrier1InCommand', true); // Set to true to open
//         console.log('GVL.mainGateBoomBarrier1InCommand, Value written:', res.value);
        
//         // Set a timeout to close the boom gate after 2 seconds
//         setTimeout(async () => {
//             await closeFourWheelerMainEntryBoom();
//         }, 2000);
//     } catch (err) {
//         console.log('Something failed:', err);
//         return false;
//     }
// }

// // Async function to close the main entry boom gate for four-wheelers
// async function closeFourWheelerMainEntryBoom() {
//     let connectionStatus = await connectClient();
//     console.log("connectionStatus====", connectionStatus);

//     try {
//         const res = await client.writeSymbol('GVL.mainGateBoomBarrier1InCommand', false); // Set to false to close
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false);
//         console.log('GVL.mainGateBoomBarrier1InCommand, Value written:', res.value);
//         return true;
//     } catch (err) {
//         console.log('Something failed:', err);
//         return false;
//     }
// }

async function connectClient2(){

    // console.log("client2.connection.connected)===",client.connection.connected)

    if(client2.connection.connected){
        return true;
    }

    connectionStatus = await client2.connect();
    // console.log("connectionStatus+++++++",connectionStatus)
    console.dir(connectionStatus,{depth:2});
    return connectionStatus.connected;

}


async function openFourWheelerEntryBoom1(){
    // console.log("Inside entry Boom 1 ..")
    
    let connectionStatus = await connectClient2();
    // console.log('connectionStatus====',connectionStatus);

    
    try {
        const vtran = await client2.writeSymbol('GVL.is_vehicle_transaction_on', true)
        const res = await client2.writeSymbol('GVL.parkingBoomBarrier1InCommand', true)
        // console.log('GVL.parkingBoomBarrier1InCommand , Value written:', res.value);
        setTimeout(async function(){
            return await closeFourWheelerEntryBoom1();
        },2000);
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
    
}

async function closeFourWheelerEntryBoom1(){

    // console.log("Inside exit booom 1..")

    let connectionStatus = await connectClient2();
    // console.log('connectionStatusclose===',connectionStatus);

    try {
        const res = await client2.writeSymbol('GVL.parkingBoomBarrier1InCommand', false)
        const vtran = await client2.writeSymbol('GVL.is_vehicle_transaction_on', false)
        // console.log('GVL.parkingBoomBarrier1OutCommand , Value written:', res.value);
        return true;
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
}


// =========================
async function openFourWheelerMainEntryBoom(){
    // console.log("Inside main entry Boom   ..")
    
    let connectionStatus = await connectClient();
    // console.log('connectionStatus====',connectionStatus);

    
    try {
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true)
        const res = await client.writeSymbol('GVL.mainGateBoomBarrier1InCommand', true)
        // console.log('GVL.mainGateBoomBarrier1InCommand , Value written:', res.value);
        setTimeout(async function(){
            return await closeFourWheelerMainEntryBoom();
        },2000);
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
    
}

async function closeFourWheelerMainEntryBoom(){

    // console.log("Inside main exit booom ...")

    let connectionStatus = await connectClient();
    // console.log('connectionStatusclose===',connectionStatus);

    try {
        const res = await client.writeSymbol('GVL.mainGateBoomBarrier1InCommand', false)
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false)
        // console.log('GVL.mainGateBoomBarrier1OutCommand , Value written:', res.value);
        return true;
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
}

//======================
// async function openFourWheelerEntryBoom2(){
    
//     let connectionStatus = await connectClient();
//     // console.log(connectionStatus);

    
//     try {
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true)
//         const res = await client.writeSymbol('GVL.parkingBoomBarrier2InCommand', true)
//         console.log('GVL.parkingBoomBarrier2InCommand , Value written:', res.value);
//         setTimeout(async function(){
//             return await closeFourWheelerEntryBoom2();
//         },2000);
//     } catch (err) {
//         console.log('Something failed:', err)
//         return false;
//     }
    
// }


// async function closeFourWheelerEntryBoom2(){

//     let connectionStatus = await connectClient();
//     // console.log(connectionStatus);

//     try {
//         const res = await client.writeSymbol('GVL.parkingBoomBarrier2InCommand', false)
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false)
//         console.log('GVL.parkingBoomBarrier2OutCommand , Value written:', res.value);
//         return true;
//     } catch (err) {
//         console.log('Something failed:', err)
//         return false;
//     }
// }

// async function openFourWheelerMainEntryBoom(){
    
//     let connectionStatus = await connectClient();
//     console.log("connectionStatus===",connectionStatus);

    
//     try {
//         // const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true)
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true);

//         const res = await client.writeSymbol('GVL.mainGateBoomBarrier1InCommand ', true)//===
//         console.log('GVL.mainGateBoomBarrier1InCommand  , Value written:', res.value);
//         setTimeout(async function(){
//             return await closeFourWheelerMainEntryBoom();
//         },2000);
//     } catch (err) {
//         console.log('Something failed:', err)
//         return false;
//     }
    
// }
// async function closeFourWheelerMainEntryBoom(){

//     let connectionStatus = await connectClient();
//     console.log("connectionStatusclose====",connectionStatus);

//     try {
//         const res = await client.writeSymbol('GVL.mainGateBoomBarrier1InCommand', false) //===
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false)
//         console.log('GVL.mainGateBoomBarrier2OutCommand  , Value written:', res.value);
//         return true;
//     } catch (err) {
//         console.log('Something failed:', err)
//         return false;
//     }
// }


async function openFourWheelerExitBoom1(){
    
    let connectionStatus = await connectClient2();
    // console.log("connectionStatus====",connectionStatus);

    
    try {
        const vtran = await client2.writeSymbol('GVL.is_vehicle_transaction_on', true)
        const res = await client2.writeSymbol('GVL.parkingBoomBarrier1OutCommand', true)
        // console.log('GVL.parkingBoomBarrier1OutCommand, Value written:', res.value);
        setTimeout(async function(){
            return await closeFourWheelerExitBoom1();
        },2000);
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
    
}

async function closeFourWheelerExitBoom1(){

    let connectionStatus = await connectClient2();
    // console.log("connectionStatusclose====",connectionStatus);

    try {
        const res = await client2.writeSymbol('GVL.parkingBoomBarrier1OutCommand', false)
        const vtran = await client2.writeSymbol('GVL.is_vehicle_transaction_on', false)
        // console.log('GVL.parkingBoomBarrier1OutCommand , Value written:', res.value);
        return true;
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
}

// async function openFourWheelerExitBoom2(){
    
//     let connectionStatus = await connectClient();
//     console.log(connectionStatus);

    
//     try {
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true)
//         const res = await client.writeSymbol('GVL.parkingBoomBarrier2OutCommand', true)
//         console.log('GVL.parkingBoomBarrier2OutCommand, Value written:', res.value);
//         setTimeout(async function(){
//             return await closeFourWheelerExitBoom2();
//         },2000);
//     } catch (err) {
//         console.log('Something failed:', err)
//         return false;
//     }
    
// }

// async function closeFourWheelerExitBoom2(){

//     let connectionStatus = await connectClient();
//     console.log(connectionStatus);

//     try {
//         const res = await client.writeSymbol('GVL.parkingBoomBarrier2OutCommand', false)
//         const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false)
//         console.log('GVL.parkingBoomBarrier2OutCommand , Value written:', res.value);
//         return true;
//     } catch (err) {
//         console.log('Something failed:', err)
//         return false;
//     }
// }


async function openFourWheelerMainExitBoom(){
    
    let connectionStatus = await connectClient();
    // console.log("connectionStatus===",connectionStatus);

    
    try {
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true)
        const res = await client.writeSymbol('GVL.mainGateBoomBarrier2OutCommand ', true) //===
        // console.log('GVL.mainGateBoomBarrier2OutCommand , Value written:', res.value); ///===
        setTimeout(async function(){
            return await closeFourWheelerMainExitBoom();
        },2000);
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
    
}

async function closeFourWheelerMainExitBoom(){

    let connectionStatus = await connectClient();
    // console.log("connectionStatusclose===",connectionStatus);

    try {
        const res = await client.writeSymbol('GVL.mainGateBoomBarrier2OutCommand ', false)//==
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false) //==
        // console.log('GVL.mainGateBoomBarrier2OutCommand  , Value written:', res.value);//==
        return true;
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
}

// connectClient();

module.exports = {
    openFourWheelerEntryBoom1,
    // openFourWheelerEntryBoom2,
    openFourWheelerExitBoom1,
    // openFourWheelerExitBoom2,
    openFourWheelerMainEntryBoom,
    openFourWheelerMainExitBoom


 }
