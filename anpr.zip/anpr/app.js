var express = require('express');
var db = require("./database");
const bodyParser = require("body-parser");
const plc = require('./plc');
// const mqtt = require('./mqtt');
const synchronizeEntryLogs = require('./database').synchronizeEntryLogs;
const synchronizeLocalDataOnline = require('./database').synchronizeLocalDataOnline;
const checkCameraIdForFourWheeler = require('./database').checkCameraIdForFourWheeler;
const vehicleCount = require('./vehicleCount');
const createVehicleCountEntryLog = require('./database').createVehicleCountEntryLog;
const axios = require('axios');
const https = require('https'); // Only import https if your link uses https
const FormData = require('form-data');
const fs = require('fs');


// Initialize totals
let totals = {
    company_counts: {},
    overall_totals: { in_count: 0, out_count: 0 }
};
async function initializeTotals() {
    try {
        totals = await db.getAllInitialCounts();
        console.log("totals in ==", totals);
    } catch (error) {
        console.error('Error initializing totals:', error);
    }
}

let totalCache = {}
async function getInitialCache() {
    try {
        totalCache = await db.initializeCaches();
        console.log("totals ==", totalCache);
        console.log("initial cache==",totalCache.whitelistCache)
    } catch (error) {
        console.error("Error initializing:", error);
    }
}



// Initialize the totals asynchronously
async function startServer() {
    // Wait for caches to load
    await initializeTotals();
    // await initializeLiveCompanyCounts();
    await getInitialCache();

    // Now start the server
    app.listen(port, () => {
    console.log(`NodeJS Server for listening to Panasonic ANPR Data. Running on port:${port}`);
    console.log(`Developed by : Claypot Technologies`);
    console.log('Author : Gautam Kulkarni')
  })
}

startServer();




var app = express();
const port = 2202;

// serve your css as static
app.use(express.static(__dirname));

// get our app to use body parser 
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json());



setInterval(async function () {
  try {

    await db.syncData();
  } catch (error) {
    console.error('Error synchronizing entry logs:', error);
  }
}, 5000)




async function sendImageToANPRAPI(imageData, plateNumber) {
  try {
      const form = new FormData();

      // console.log("imageData==",imageData)
      // console.log("plateNumber==",plateNumber)

      // Check if the image data is valid and append it properly
      if (!imageData || imageData === 0) {
          console.error("No image data provided");
          return { success: false, reason: "No Image data provided" };
      }

      // If image data is a URL or base64, ensure it's appended correctly
      form.append('image_data', imageData); // This should be base64 string or image URL
      form.append('image_name', plateNumber); // Plate number as the image name

      // Send the image to the API
      const response = await axios.post('https://www.octopus-automation.com/apps/lightbridge/anpr_image_saver.php', form, {
          headers: {
              ...form.getHeaders() // Make sure to add form headers
          }
      });
      // Return the response from ANPR API
      return response.data;
  } catch (error) {
      console.error("Error uploading image to ANPR API:", error);
      return null; // Return null in case of an error
  }
}


const lastVehicleEntryTimestamps = {
  'new-plate-parking-entry-1': new Date(),
  
  'new-plate-main-entry': new Date(),
  'new-plate-parking-exit-1': new Date(),
  
  'new-plate-main-exit': new Date()
};

// 2. Dummy data insertion logic
const DUMMY_INTERVAL = (60 * 60 * 1000) - (5 * 1000); // 59m 55s
// const DUMMY_INTERVAL = 2 * 60 * 1000; // 2 minutes testing 
const CHECK_INTERVAL = 5 * 1000;    // check every 5 seconds

setInterval(async () => {
  const now = new Date();

  for (const cameraId of Object.keys(lastVehicleEntryTimestamps)) {
    const timeSinceLastEntry = now - lastVehicleEntryTimestamps[cameraId];

    if (timeSinceLastEntry > DUMMY_INTERVAL) {
      console.log(`${cameraId}: No entry in the past hour, inserting dummy data...`);

      const dummyPlate = '0';
      const dummyImage = '0';
      const badNo = 0;
      const dummyData = { id: 0, vehicle_number: dummyPlate };

      try {
        if (cameraId === 'new-plate-parking-entry-1') {
          await db.createFourWheelerEntryLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for parking entry 1.`);
        } else if (cameraId === 'new-plate-main-entry') {
          await db.createFourWheelerMainEntryLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for main entry.`);
        }else if (cameraId === 'new-plate-parking-exit-1') {
          await db.createFourWheelerExitLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for parking exit 1.`);
        }else if (cameraId === 'new-plate-main-exit') {
          await db.createFourWheelerMainExitLog(dummyData, dummyImage, false, badNo);
          console.log(`${cameraId}: Dummy data inserted successfully for main exit.`);
        }

        // Reset timestamp after dummy data insertion
        lastVehicleEntryTimestamps[cameraId] = new Date();

      } catch (error) {
        console.error(`${cameraId}: Failed to insert dummy data:`, error);
      }
    } else {
      const totalSeconds = Math.floor(timeSinceLastEntry / 1000);
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
      console.log(`${cameraId}: Last real entry was ${formattedTime} (mm:ss) ago, waiting...`);
          }
  }
}, CHECK_INTERVAL);

function sendTelegramAlerts(messages, photoUrlOverride = null) {
  try {
    if (!Array.isArray(messages)) messages = [messages];
    const combinedMessage = messages.join('\n');

    const photoUrl =
      photoUrlOverride ||
      'https://www.octopus-automation.com/apps/eqi/images/telegram/tank.jpg';

    const BOT_TOKEN = '5854610426:AAF2F6aBmlNXnEUoG-Lzub7VR19UlNY21JU';
    const CHAT_ID   = '-1001640441317';

    const now = new Date();
    const timeStamp = now.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
    const caption = `${combinedMessage}\n\n<i>* Automated ANPR Alert @ ${timeStamp} *</i>`;

    const url =
      `https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto` +
      `?chat_id=${CHAT_ID}` +
      `&photo=${photoUrl}` +                     // unencoded
      `&caption=${encodeURIComponent(caption)}` +
      `&parse_mode=html`;

    https
      .get(url, (response) => {
        console.log('Telegram API response status:', response.statusCode);
        response.resume();
      })
      .on('error', (err) => {
        console.error('Telegram API call error:', err.message);
      });
  } catch (err) {
    console.error('Error building telegram message:', err.message);
  }
}

app.post("/new-plate-parking-entry-1", async (req, res) => {
  console.log(`@ ${new Date()}`);

  lastVehicleEntryTimestamps['new-plate-parking-entry-1'] = new Date(); // Update timestamp

  const vehiclePlateNumber = req.body.plate?.toUpperCase();
  const vehicleImage = req.body.plateimage || 0;

  if (!vehiclePlateNumber) {
    return res.status(400).send({ error: "Plate number is missing" });
  }

  try {
    // 1 Check whitelist using in-memory cache
    const vehicleDetails = totalCache.whitelistCache.find(
      v => v.vehicle_number === vehiclePlateNumber
    );

    // Determine companyName
    const companyName = vehicleDetails?.company_name || "Not-WhiteListed";

    // Ensure company exists in totals cache
    if (!totals.company_counts[companyName]) {
      totals.company_counts[companyName] = { in_count: 0, out_count: 0 };
    }

    // 2️ Check bad number list
    const isBadNumber = await db.checkBadNumber(vehiclePlateNumber);
    const badNo = isBadNumber ? 1 : 0;

    // 3️ Update totals in memory
    totals.overall_totals.in_count++;
    totals.company_counts[companyName].in_count++;

    // 4 Upload image to ANPR API
    const imageUploadResponse = await sendImageToANPRAPI(vehicleImage, vehiclePlateNumber);
    const savedImage = imageUploadResponse?.success === true ? "file" : vehicleImage;

    console.log("Image upload resp==",imageUploadResponse)
    if (imageUploadResponse?.success && imageUploadResponse?.imgName) {
      // ✅ correct construction for your current PHP response
      uploadedImageUrl = `https://www.octopus-automation.com/apps/lightbridge/anpr_images/${imageUploadResponse.imgName}`;
    } else {
      // 🪣 fallback in case upload failed or field missing
      uploadedImageUrl = 'https://www.octopus-automation.com/apps/eqi/images/telegram/tank.jpg';
    }
    console.log("✅ Final uploadedImageUrl:", uploadedImageUrl);

    // 5 Trigger boom for whitelisted vehicles only
    if (vehicleDetails) {
      console.log(`✅ Opening boom for whitelisted vehicle ${vehiclePlateNumber}`);
      await plc.openFourWheelerEntryBoom1();
    } else {
      console.log(` Vehicle ${vehiclePlateNumber} is NOT whitelisted`);
      sendTelegramAlerts([
        ` Vehicle ${vehiclePlateNumber} does not exist in our whitelist. Not allowed inside premise.`
      ],uploadedImageUrl);
      
    }

    

    // 6️ Create entry log in DB
    await db.createFourWheelerEntryLog(
      { id: 0, vehicle_number: vehiclePlateNumber },
      savedImage,
      !!vehicleDetails, // true if whitelisted
      badNo
    );

    // 7️ Update hourly counts in MySQL table
    await db.updateCompanyVehicleCount(companyName, "IN");

    // 8️ Optional: log totals for debugging
    console.log("Updated totals for company:", companyName, totals.company_counts[companyName]);

    const liveInCount = totals.company_counts[companyName].in_count - totals.company_counts[companyName].out_count;
    const limit = totalCache.companyLimitsCache[companyName] || 0;

    if (limit > 0 && liveInCount > limit) {
        console.warn(` Vehicle ${vehiclePlateNumber} exceeds limit for ${companyName} (${liveInCount}/${limit})`);
        sendTelegramAlerts([
            ` Vehicle ${vehiclePlateNumber} belongs to ${companyName}, allotted parking slots (${liveInCount}/${limit}) full. Not allowed inside premise.`
        ],uploadedImageUrl);
    }


    

    res.send(true);

  } catch (error) {
    console.error("Error during processing the entry:", error);
    res.status(500).send({ error: "Internal server error during processing the entry" });
  }
});



function getISTDateTime() {
    const now = new Date();
    // IST is UTC+5:30
    const istOffset = 5.5 * 60; // minutes
    const istTime = new Date(now.getTime() + (istOffset + now.getTimezoneOffset()) * 60000);
    const yyyy = istTime.getFullYear();
    const mm = String(istTime.getMonth() + 1).padStart(2, '0');
    const dd = String(istTime.getDate()).padStart(2, '0');
    const hh = String(istTime.getHours()).padStart(2, '0');
    const min = String(istTime.getMinutes()).padStart(2, '0');
    const ss = String(istTime.getSeconds()).padStart(2, '0');

    return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
}





async function updateLiveCompanyCounts() {
  const promisePool = db.pool.promise(); // make sure db.pool is correctly imported

  try {
    for (const companyName of Object.keys(totals.company_counts)) {
      try {
        const inCount = totals.company_counts[companyName].in_count;
        const outCount = totals.company_counts[companyName].out_count;
        const liveCount = inCount - outCount;
        const istDateTime = getISTDateTime();

        await promisePool.query(
          `INSERT INTO lightbridge_company_live_count
            (company_name, live_in, live_out, live_count, updated_at)
          VALUES (?, ?, ?, ?, ?)`,
          [companyName, inCount, outCount, liveCount, getISTDateTime()]
        );
        console.log(`Inserted live snapshot for ${companyName}: ${liveCount} at ${istDateTime}`);
      } catch (err) {
        console.error(`❌ Error inserting for ${companyName}:`, err);
      }
    }
  } catch (err) {
    console.error("❌ Error updating live company counts snapshot:", err);
  }
}

// Run every 1 minute
setInterval(updateLiveCompanyCounts, 60 * 1000);


app.post("/new-plate-parking-exit-1", async (req, res) => {
  console.log(`@ ${new Date()}`);
  lastVehicleEntryTimestamps['new-plate-parking-exit-1'] = new Date();

  const vehiclePlateNumber = req.body.plate?.toUpperCase();
  const vehicleImage = req.body.plateimage || 0;

  if (!vehiclePlateNumber) {
    return res.status(400).send({ error: "Plate number is missing" });
  }

  try {
    // 1️ Check whitelist using in-memory cache
    const vehicleDetails = totalCache.whitelistCache.find(
      v => v.vehicle_number === vehiclePlateNumber
    );

    // Determine companyName
    const companyName = vehicleDetails?.company_name || "Not-WhiteListed";

    // Ensure company exists in totals cache
    if (!totals.company_counts[companyName]) {
      totals.company_counts[companyName] = { in_count: 0, out_count: 0 };
    }

    // 2️ Check bad number list
    const isBadNumber = await db.checkBadNumber(vehiclePlateNumber);
    const badNo = isBadNumber ? 1 : 0;

    // 3️ Update totals in memory
    totals.overall_totals.out_count++;
    totals.company_counts[companyName].out_count++;

    // 4️ Trigger boom for exit
    
    console.log(`✅ Opening exit boom for vehicle ${vehiclePlateNumber}`);
    await plc.openFourWheelerExitBoom1();
    
    

    // 5️ Upload image to ANPR API
    const imageUploadResponse = await sendImageToANPRAPI(vehicleImage, vehiclePlateNumber);
    const savedImage = imageUploadResponse?.success === true ? "file" : vehicleImage;

 
    // 6️ Create exit log in DB
    await db.createFourWheelerExitLog(
      { id: 0, vehicle_number: vehiclePlateNumber },
      savedImage,
      !!vehicleDetails, // true if whitelisted
      badNo
    );

    // 7️ Update hourly counts in MySQL table
    await db.updateCompanyVehicleCount(companyName, "OUT");

    // 8️ Calculate live in count after exit
    const liveInCount = totals.company_counts[companyName].in_count - totals.company_counts[companyName].out_count;
    console.log(`Live count for ${companyName} after exit: ${liveInCount}`);
    
    res.send(true);

  } catch (error) {
    console.error("Error during processing the exit:", error);
    res.status(500).send({ error: "Internal server error during processing the exit" });
  }
});

app.post("/new-plate-main-entry", async (req, res) => {
  // console.log('\n\n----------------');
  // console.log(req.body);
  // console.log(`@ ${new Date()}`);

  lastVehicleEntryTimestamps['new-plate-main-entry'] = new Date(); // Update timestamp

  if (!req.body.plate) {
    // console.log("Invalid request: plate number is missing");
    return res.status(400).send({ error: "Plate number is missing" });
  }

  if (req.body.hasOwnProperty("plate") && req.body.plate) {
    var vehicleImage = 0;
    var vehiclePlateNumber = 0;
    if (req.body.hasOwnProperty("plateimage")) {
      vehicleImage = req.body.plateimage;
    }
    if (req.body.hasOwnProperty("plate")) {
      vehiclePlateNumber = req.body.plate;
    }

    try {
      // const vehicleDetails = await db.checkWhiteList(req.body.plate);
      // Check if the vehicle is in the bad number list
      const isBadNumber = await db.checkBadNumber(req.body.plate);

      // Default badNo to 0 (non-bad number vehicle)
      let badNo = 0;

      // If vehicle is in the bad number list, set badNo to 1
      if (isBadNumber) {
        badNo = 1;
      }

      // if (vehicleDetails) { // if vehicle number was found in the whitelist
        // console.log("Open Four Wheeler main entry boom for whitelisted vehicle!");
        // open booooooooooooooooooooom
        await plc.openFourWheelerMainEntryBoom();  
        
        // await db.createFourWheelerMainEntryLog(
        //   { id: 0, vehicle_number: vehiclePlateNumber },
        //     'file', // Indicates the image is saved on ANPR API
        //     true,
        //     badNo
        // );

        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
        // console.log("imageUploadResponse===",imageUploadResponse)
        
        // Handle the response from the ANPR API
        if (imageUploadResponse && imageUploadResponse.success === true) {
            // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
            // console.log("vehicleImg----",req.body.plateimage)
            // Update the database with "file" if the image is successfully saved
            await db.createFourWheelerMainEntryLog(
              { id: 0, vehicle_number: vehiclePlateNumber },
                'file', // Indicates the image is saved on ANPR API
                true,
                badNo
            );
        } else {
            // console.log("storing image URL......");
            // console.log("vehicleImg----",req.body.plateimage)
            // If failed, store the image URL in the database
            await db.createFourWheelerMainEntryLog(
                { id: 0, vehicle_number: vehiclePlateNumber },
                req.body.plateimage, // Storing the image URL in the database
                true,
                badNo
            );
        }
       

      res.send(true);
    } catch (error) {
      console.error("Error during processing the entry:", error);
      // res.status(500).send({ error: "Internal server error during processing the entry" });
    }
  } else {
    // res.status(400).send({ error: "Invalid request: plate number is missing" });
    // console.log("Invalid request: plate number is missing")
  }
});





app.post("/new-plate-main-exit", async (req, res) => {
  // console.log('\n\n----------------');
  // console.log(req.body);
  // console.log(`@ ${new Date()}`);

  lastVehicleEntryTimestamps['new-plate-main-exit'] = new Date(); // Update timestamp

  if (!req.body.plate) {
    // console.log("Invalid request: plate number is missing");
    return res.status(400).send({ error: "Plate number is missing" });
  }

  if(req.body.hasOwnProperty("plate") && req.body.plate){
  
    
    if(req.body.hasOwnProperty("plateimage")){vehicleImage = req.body.plateimage};
    if (req.body.hasOwnProperty("plate")) {
      vehiclePlateNumber = req.body.plate;
    }
    try {
      // Check if the vehicle is in the whitelist
      // const vehicleDetails = await db.checkWhiteList(req.body.plate);
      // Check if the vehicle is in the bad number list
      const isBadNumber = await db.checkBadNumber(req.body.plate);

      // Default badNo to 0 (non-bad number vehicle)
      let badNo = 0;

      // If vehicle is in the bad number list, set badNo to 1
      if (isBadNumber) {
        badNo = 1;
      }

      // If vehicle is found in the whitelist
      // if (vehicleDetails) {
        // console.log("Open Four Wheeler Main exit boom for whitelisted vehicle!")
        // open boooooooooooooooooooom;
        await plc.openFourWheelerMainExitBoom();
        // await db.createFourWheelerMainExitLog(
              //   { id: 0, vehicle_number: vehiclePlateNumber },
              //     'file', // Indicates the image is saved on ANPR API
              //     true,
              //     badNo
              // );
        const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
            // console.log("imageUploadResponse===",imageUploadResponse)
            
            // Handle the response from the ANPR API
            if (imageUploadResponse && imageUploadResponse.success === true) {
                // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
                // console.log("vehicleImg----",req.body.plateimage)
                // Update the database with "file" if the image is successfully saved
                await db.createFourWheelerMainExitLog(
                  { id: 0, vehicle_number: vehiclePlateNumber },
                    'file', // Indicates the image is saved on ANPR API
                    true,
                    badNo
                );
            } else {
                // console.log("storing image URL......");
                // console.log("vehicleImg----",req.body.plateimage)
                // If failed, store the image URL in the database
                await db.createFourWheelerMainExitLog(
                    { id: 0, vehicle_number: vehiclePlateNumber },
                    req.body.plateimage, // Storing the image URL in the database
                    true,
                    badNo
                );
            }
      // } else {
      //   // console.log("Open Four Wheeler Main exit boom for non-whitelisted vehicle!");
      //   // open boom
      //   await plc.openFourWheelerMainExitBoom(); 
      //   // Log for non-whitelisted vehicles with bad_no (0)
      //   // db.createFourWheelerMainExitLog({ id: 0, vehicle_number: req.body.plate }, vehicleImage, false, badNo);
      //   // await db.createFourWheelerMainExitLog(
      //   //   { id: 0, vehicle_number: vehiclePlateNumber },
      //   //     'file', // Indicates the image is saved on ANPR API
      //   //     false,
      //   //     badNo
      //   // );
      //   const imageUploadResponse = await sendImageToANPRAPI(req.body.plateimage, vehiclePlateNumber);
      //       // console.log("imageUploadResponse===",imageUploadResponse)
            
      //       // Handle the response from the ANPR API
      //       if (imageUploadResponse && imageUploadResponse.success === true) {
      //           // console.log("Image saved successfully on ANPR API:", imageUploadResponse.imgName);
      //           // console.log("vehicleImg----",req.body.plateimage)
      //           // Update the database with "file" if the image is successfully saved
      //           await db.createFourWheelerMainExitLog(
      //             { id: 0, vehicle_number: vehiclePlateNumber },
      //               'file', // Indicates the image is saved on ANPR API
      //               false,
      //               badNo
      //           );
      //       } else {
      //       //     console.log("storing image URL......");
      //       //     console.log("vehicleImg----",req.body.plateimage)
      //           // If failed, store the image URL in the database
      //           await db.createFourWheelerMainExitLog(
      //               { id: 0, vehicle_number: vehiclePlateNumber },
      //               req.body.plateimage, // Storing the image URL in the database
      //               false,
      //               badNo
      //           );
      //       }
      // }
      res.send(true);
    } catch (error) {
      console.error("Error during processing the main exit:", error);
      res.status(500).send({ error: "Internal server error" });
    }
  } else {
    // console.log("Invalid request: plate number is missing");
    res.status(400).send({ error: "Plate number is missing" });
  }
});


function resetTotals() {
    totals = {
        company_counts: {},
        overall_totals: { in_count: 0, out_count: 0 }
    };
    console.log("Totals reset to 0 at end of day:", new Date().toISOString());
}

// Schedule daily reset at 23:59:59
function scheduleDailyReset() {
    const now = new Date();
    const targetTime = new Date();
    targetTime.setHours(23, 59, 59, 0);
    
    // If it's already past 23:59:59 today, schedule for tomorrow
    if (now > targetTime) {
        targetTime.setDate(targetTime.getDate() + 1);
    }
    
    const timeUntilReset = targetTime.getTime() - now.getTime();
    
    setTimeout(() => {
        resetTotals();
        // Schedule next reset for the following day
        scheduleDailyReset();
    }, timeUntilReset);
    
    console.log(`Daily reset scheduled for: ${targetTime}`);
}

// Start the scheduler
scheduleDailyReset();


app.post("/vehicleCount", async (req, res) => {
  // console.log("Receiving vehicle count data....");
  console.dir(req.body, { depth: 4 });
  // console.log(`@ ${new Date()}`);

  try {
      // Assuming `getVehicleCounts` processes the data and generates the required counts
      const counts = vehicleCount.getVehicleCounts(req.body);
      console.log("Processed counts:", counts); // Log the counts here to check

      if (!counts) {
          throw new Error('Counts are undefined or invalid');
      }

      // Call `createVehicleCountEntryLog` with the processed counts
      await createVehicleCountEntryLog(counts);

      res.send({ success: true });
  } catch (error) {
      console.error("Error while processing vehicle count data:", error);
      res.status(500).send({ error: "Internal server error during vehicle count processing" });
  }
});



// app.listen(port, () => {
//     console.log(`NodeJS Server for listening to Panasonic ANPR Data. Running on port:${port}`);
//     console.log(`Developed by : Claypot Technologies`);
//     console.log('Author : Gautam Kulkarni')
//   })


