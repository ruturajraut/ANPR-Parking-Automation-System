controller_net_id="192.168.20.65.1.1"
controller_net_id2 = "192.168.20.58.1.1"
controller_port = 851

camera_ip = "192.168.15.78"


mysql_details = {
    mysqlHostName : "yourhostname.amazonaws.com",
    mysqlPort : 3306,
    mysqlUser : "user",
    mysqlPassword : "pass",
    mysqlDatabase : "lightbridge_db",
    whitelistTable : "lightbridge_numberplate_whitelist",
    entryLogTable : "lightbridge_anpr_logs",
    currentVehiclesTable : "lightbridge_current_vehicles",
    countLogTable : "lightbridge_parking_count_panasonic",
    badNumberTable: 'lightbridge_bad_numbers'
}
mysql_details_local = {
    mysqlHostName : "localhost",
    mysqlPort : 3306,
    mysqlUser : "root",
    mysqlPassword : "root",
    mysqlDatabase : "lightbridge_db",
    entryLogTable : "lightbridge_anpr_logs_local",
    currentVehiclesTable : "lightbridge_current_vehicles_local",
    countLogTable : 'lightbridge_parking_count_panasonic_local'
}

module.exports = {
    controller_net_id,
    controller_net_id2,
    controller_port,
    mqtt_broker_details,
    mysql_details,mysql_details_local
}
