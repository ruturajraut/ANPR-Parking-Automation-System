var ads = require('node-ads');

var ads_options = {
    //The IP or hostname of the target machine
    host: "192.168.20.54",
    //The NetId of the target machine
    amsNetIdTarget: "5.103.230.188.1.1",
    //The NetId of the source machine.
    //You can choose anything in the form of x.x.x.x.x.x,
    //but on the target machine this must be added as a route.
    amsNetIdSource: "169.254.119.135.1.1",
 
    //OPTIONAL: (These are set by default)
    //The tcp destination port
    //port: 48898
    //The ams source port
    //amsPortSource: 32905
    //The ams target port for TwinCat 2 Runtime 1 
    //amsPortTarget: 801 
    //The ams target port for TwinCat 3 Runtime 1
    amsPortTarget: 851 
    //The timeout for PLC requests
    //timeout: 500
    //The Local address the socket should connect from
    //localAddress: "192.168.137.50"
    //The Local port the socket should connect from
    //localPort: 50000
    //Version of IP stack. Must be 4, 6, or 0. The value 0 indicates that both IPv4 and IPv6 addresses are allowed. Default: 0
    //family: 4
}

var isControllerAvailableHandle = {
    //Handle name in twincat
    symname: 'GVL.controller_available',  
    //An ads type object or an array of type objects.
    //You can also specify a number or an array of numbers,
    //the result will then be a buffer object.
    //If not defined, the default will be BOOL.
    bytelength: ads.BOOL,  
    //The propery name where the value should be written.
    //This can be an array with the same length as the array length of byteLength.
    //If not defined, the default will be 'value'.     
    propname: 'value'      
}

var basementBoomBarrierOutCommandHandle = {
    //Handle name in twincat
    symname: 'GVL.basementBoomBarrierOutCommand',  
    //An ads type object or an array of type objects.
    //You can also specify a number or an array of numbers,
    //the result will then be a buffer object.
    //If not defined, the default will be BOOL.
    bytelength: ads.BOOL,  
    //The propery name where the value should be written.
    //This can be an array with the same length as the array length of byteLength.
    //If not defined, the default will be 'value'.     
    propname: 'value'
}

var ads_client = ads.connect(ads_options, function() {
    // this.readDeviceInfo(function(err, result) {
    //     if (err) console.log(err)
    //     console.log(result)
    //     this.end()
    // })

    this.read(isControllerAvailableHandle, function(err, handle) {
        if (err) console.log(err)
        //result is the myHandle object with the new properties filled in
        console.log(`controller connected = ${isControllerAvailableHandle.value}`)
        //All handles will be released automaticly here
        this.end()
    })
})
 
ads_client.on('error', function(error) {
    console.log(error)
})

function openBoom(callback){
    var ads_client = ads.connect(ads_options, function() {
        basementBoomBarrierOutCommandHandle.value = 0;
        console.log(basementBoomBarrierOutCommandHandle);
        this.write(basementBoomBarrierOutCommandHandle, function(err) {
            if (err){
                callback("error opening boom")
                console.log(err);
                // callback(err)
                this.end();
                // return;
            }
            else{
                this.end();
                callback(null,"Boom opened successfully")
                setTimeout(closeBoom,2000)
                
            }
            
            
            // this.read(myHandle, function(err, handle) {
            //     if (err) console.log(err)
            //     console.log(handle.value)
            //     this.end()
            // })
        })
    })
}

function closeBoom(){
    var ads_client = ads.connect(ads_options, function() {
        basementBoomBarrierOutCommandHandle.value = 0;
        console.log(basementBoomBarrierOutCommandHandle);

        this.write(basementBoomBarrierOutCommandHandle, function(err) {
            if (err){
                console.log("error closing boom")
                console.log(err);
                // callback(err)
                this.end()
                // return;
            }
            else{
                console.log("Boom closed successfully")
                this.end();
            }
        })
    })
}

module.exports = {
    openBoom
 }
